import React, { useState } from "react";

import css from "./App.module.css";
import { Login } from "./Login/Login";



function App() {
  
  return (
    <div className={css.App}>
      <Login />
    </div>
  );
}

export default App;
